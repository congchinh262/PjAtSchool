//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price){
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function Usb(){
	var a = new Array();
	a[0]=new sanpham("USB 2.0 OTG 16GB Adata.jfif","USB00","USB OTG",300000);
	a[1]=new sanpham("USB 3.0 32GB Sandisk.png","USB01","USB Sandisk 32GB",650000);
	a[2]=new sanpham("USB 3.0 OTG 16GB Sandisk.png","USB02","USB Sandisk 16GB",310000);
	a[3]=new sanpham("USB 3.0 OTG lightning 32GB Sandisk Ixpand Mini.png","USB03","USB OTG Lightning 32GB",400000);
	a[4]=new sanpham("Usb 3.0 OTG Type-C 32G Sandisk.png","USB04","USB OTG Type",650000);
	a[5]=new sanpham("USB Sandisk SDCZ50 8GB 2.0.jpg","USB05","USB Sandisk 8GB",610000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = Usb();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image/LKRapMay/Phukien/USB/"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}
window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=8;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = Usb();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image/LKRapMay/Phukien/USB/"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});
