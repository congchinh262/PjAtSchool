//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price){
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function TanNhiet(){
	var a = new Array();
	a[0]=new sanpham("Linh kiện tản nhiệt nước - Block EK-RAM Monarch X4 - Nickel.jpg","TNH00","Tản nhiệt Nickel",300000);
	a[1]=new sanpham("Tản nhiệt nước cho CPU DEEPCOOL Castle 240 RGB.jpg","TNH01","Tản nhiệt DEELCOOL",650000);
	a[2]=new sanpham("Tản nhiệt nước CPU cooler master MASTERLIQUID ML240R .jpg","TNH02","Tản nhiệt MASTERLIQUID",310000);
	a[3]=new sanpham("Tản nhiệt nước CPU corsair Hydro Series™ H115i PRO RGB .jpg","TNH03","Tản nhiệt Hydro",400000);
	a[4]=new sanpham("Tản nhiệt nước CPU Deepcool Gammax L120 RGB.jpg","TNH04","Tản nhiệt Deelcool Gammax L120",650000);
	a[5]=new sanpham("Tản nhiệt nước CPU Deepcool Gammax L240 RGB.jpg","TNH05","Tản nhiệt Deelcool Gammax L240 ",610000);
	a[6]=new sanpham("Tản nhiệt nước custom Freezemod RGB sync KIT.jfif","TNH06","Tản nhiệt Freezemod",60000);
	a[7]=new sanpham("Tản nhiệt khí Air Cooling Deepcool gammaxx 400 (Blue).jpg","TNH07","Tản nhiệt Ari Cooling blue",300000);
	a[8]=new sanpham("Tản nhiệt khí Air Cooling Deepcool gammaxx 400 led RED.jpg","TNH08","Tản nhiệt DEELCOOL red",650000);
	a[9]=new sanpham("Tản nhiệt khí CoolerMaster Hyper 212 LED Turbo Red.jpg","TNH09","Tản nhiệt CoolerMaster",310000);
	a[10]=new sanpham("Tản nhiệt khí CPU cooler master MASTERAIR MA620P led RGB.jpg","TNH10","Tản nhiệt Cooler",400000);
	a[11]=new sanpham("Tản nhiệt khí CPU Cooler Master Wraith Ripper.jpg","TNH11","Tản nhiệt Ripper",650000);
	a[12]=new sanpham("Tản nhiệt khí CPU deepcool FRYZEN - AMD.jpg","TNH12","Tản nhiệt FRYZEN",610000);
	a[13]=new sanpham("Tản nhiệt khí CPU DEEPCOOL GAMMAXX GTE RGB.jpg","TNH13","Tản nhiệt GTE",60000);
	a[14]=new sanpham("FAN CPU LIQUID AIO ASUS ROG RYUJIN 240 AURA SYNC RGB.png","TNH14","Tản nhiệt LIQUID",300000);
	a[15]=new sanpham("FAN CPU LIQUID AIO COOLER MASTER ML360R RGB .jpg","TNH15","Tản nhiệt COOLER MASTER",650000);
	a[16]=new sanpham("FAN CPU LIQUID AIO DEEPCOOL CAPTAIN 120EX WHITE .jpg","TNH16","Tản nhiệt CAPTAIN",310000);
	a[17]=new sanpham("FAN CPU LIQUID AIO GAMER STORM CASTEL 240 RGB.jpg","TNH17","Tản nhiệt GAMEMR STORM",400000);
	a[18]=new sanpham("FAN CPU LIQUID AIO THERMALTAKE LCS FLOE RING 280.jpg","TNH18","Tản nhiệt THERMALTAKE",650000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = TanNhiet();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image/LKRapMay/Tannhiet/"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}
window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=8;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = TanNhiet();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image/LKRapMay/Tannhiet/"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});
