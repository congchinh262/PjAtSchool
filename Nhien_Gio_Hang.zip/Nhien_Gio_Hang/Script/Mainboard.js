//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price)
{
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function Main(){
	var a = new Array();
	a[0]=new sanpham("Code.jpg","MAIN00","Code",60000);
	a[1]=new sanpham("Extreme.jpg","MAIN01","Extreme",650000);
	a[2]=new sanpham("F_Gaming.jpg","MAIN02","F_Gaming",310000);
	a[3]=new sanpham("Formula.jpg","MAIN03","Formula",60000);
	a[4]=new sanpham("Mortar.jpg","MAIN04","Mortar",650000);
	a[5]=new sanpham("Pro4_F.jpg","MAIN05","Pro4_F",310000);
	a[6]=new sanpham("Z390_designare.jpg","MAIN06","Z390_designare",60000);
	a[7]=new sanpham("Z390_elite.jpg","MAIN07","Z390_elite",650000);
	a[8]=new sanpham("Z390_extreme.jpg","MAIN08","Z390_extreme",310000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = Main();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image/LKRapMay/Mainboard/"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}
window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=8;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = Main();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image/LKRapMay/Mainboard/"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});