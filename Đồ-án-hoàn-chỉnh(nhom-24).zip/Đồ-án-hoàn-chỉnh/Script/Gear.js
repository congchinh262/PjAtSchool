//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price){
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function Chuot(){
	var a = new Array();
	a[0]=new sanpham("/Gear/Chuot/CORSAIR Glaive Pro.jpg","CHUOT00","Chuột CORSAIR Glaive Pro",300000);
	a[1]=new sanpham("/Gear/Chuot/Gaming Mouse Wired Programmable 7 Buttons - Hcman .jpg","CHUOT01","Chuột Gaming Mouse Wired Programmable 7",650000);
	a[2]=new sanpham("/Gear/Chuot/LIGHTSPEED Wireless Gaming Mouse G502.png","CHUOT02","Chuột LIGHTSPEED Wireless Gaming Mouse G502",310000);
	a[3]=new sanpham("/Gear/Chuot/MMO Gaming Mouse G600.png","CHUOT03","Chuột MMO Gaming Mouse G600",400000);
	a[4]=new sanpham("/Gear/Chuot/PICTEK Gaming Mouse Wired, 8 Programmable Buttons, Chroma RGB.jpg","CHUOT04","Chuột PICTEK Gaming Mouse Wired",650000);
	a[5]=new sanpham("/Gear/Chuot/SteelSeries Rival 600.jpg","CHUOT05","Chuột SteelSeries Rival 600",100000);
	a[6]=new sanpham("/Gear/Chuot/Wireless Gaming Mouse G602.png","CHUOT06","Chuột Wireless Gaming Mouse G602",310000);
	a[7]=new sanpham("/Gear/Chuot/Wireless Gaming Mouse VEGCOO C8.jpg","CHUOT07","Chuột Wireless Gaming Mouse VEGCOO C8",610000);
	a[8]=new sanpham("/Gear/Lotchuot/Corsair MM200 Medium.jpg","LT00","Corsair MM200 Medium",60000);
	a[9]=new sanpham("/Gear/Lotchuot/Corsair MM350 Premium Anti-Fray XL.jpg","LT01","Corsair MM350 Premium Anti-Fray XL",650000);
	a[10]=new sanpham("/Gear/Lotchuot/Lót chuột Alpha Gamer Micron.jpg","LT02","Lót chuột Alpha Gamer Micron",310000);
	a[11]=new sanpham("/Gear/Lotchuot/MSI GAMING SHIELD MOUSEPAD.png","LT03","MSI GAMING SHIELD MOUSEPAD",60000);
	a[12]=new sanpham("/Gear/Lotchuot/Razer Goliathus Mobile.png","LT04","Razer Goliathus Mobile",650000);
	a[13]=new sanpham("/Gear/Lotchuot/Razer Sphex V2.jpg","LT05","Razer Sphex V2",310000);
	a[14]=new sanpham("/Gear/Lotchuot/ROG Strix Edge COD (NC03).jpg","LT06","ROG Strix Edge COD (NC03)",60000);
	a[15]=new sanpham("/Gear/Lotchuot/SteelSeries QcK Limited Micro-Woven Cloth.jpg","LT07","SteelSeries QcK Limited Micro-Woven Cloth",650000);
	a[16]=new sanpham("/Gear/Banphim/Bàn phím Asus Cerberus.jpg","BP00","Bàn phím Asus Cerberus",300000);
	a[17]=new sanpham("/Gear/Banphim/Bàn phím Corsair K68 RGB Blue switch.png","BP01","Bàn phím Corsair K68 RGB Blue switch",650000);
	a[18]=new sanpham("/Gear/Banphim/Bàn phím Cougar Aurora S.png","BP02","Bàn phím Cougar Aurora S",310000);
	a[19]=new sanpham("/Gear/Banphim/Bàn phím Durgod Taurus K320 - Nature White.jpg","BP03","Bàn phím Durgod Taurus K320 - Nature White",400000);
	a[20]=new sanpham("/Gear/Banphim/Bàn phím Durgod V87.png","BP04","Bàn phím Durgod V87",650000);
	a[21]=new sanpham("/Gear/Banphim/Bàn phím Fuhlen D (Destroyer).jpg","BP05","Bàn phím Fuhlen D (Destroyer)",610000);
	a[22]=new sanpham("/Gear/Banphim/Bàn phím Fuhlen G87 (Cherry Switches).jpg","BP06","Bàn phím Fuhlen G87 (Cherry Switches)",610000);
	a[23]=new sanpham("/Gear/Banphim/Bàn phím MSI GK70.jpg","BP07","Bàn phím MSI GK70",610000);
	a[24]=new sanpham("/Gear/Banphim/Bàn phím Rapoo V720 RGB.jpg","BP08","Bàn phím Rapoo V720 RGB",610000);
	a[25]=new sanpham("/Gear/Loa/Creative SBS A350 2.1.png","LOA00","Creative SBS A350 2.1",300000);
	a[26]=new sanpham("/Gear/Loa/Creative Sound BlasterX Katana.jpg","LOA01","Creative Sound BlasterX Katana",650000);
	a[27]=new sanpham("/Gear/Loa/Creative Sound BlasterX Kratos S5.png","LOA02","Creative Sound BlasterX Kratos S5",310000);
	a[28]=new sanpham("/Gear/Loa/Loa Edifier 2.1 M1360.jpg","LOA03","Loa Edifier 2.1 M1360",400000);
	a[29]=new sanpham("/Gear/Loa/Loa Logitech Z607 5.1.jpg","LOA04","Loa Logitech Z607 5.1",650000);
	a[30]=new sanpham("/Gear/Loa/Loa Razer Leviathan 5.1 Channel Surround Sound Bar.jpg","LOA05","Loa Razer Leviathan 5.1 Channel Surround Sound Bar",610000);
	a[31]=new sanpham("/Gear/Loa/Loa Razer Nommo Pro.png","LOA06","Loa Razer Nommo Pro",610000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = Chuot();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}
window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=12;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = Chuot();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});
