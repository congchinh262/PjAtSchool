//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price){
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function PK(){
	var a = new Array();
	a[0]=new sanpham("/LKRapMay/Phukien/USB/USB 2.0 OTG 16GB Adata.jfif","USB00","USB OTG",300000);
	a[1]=new sanpham("/LKRapMay/Phukien/USB/USB 3.0 32GB Sandisk.png","USB01","USB Sandisk 32GB",650000);
	a[2]=new sanpham("/LKRapMay/Phukien/USB/USB 3.0 OTG 16GB Sandisk.png","USB02","USB Sandisk 16GB",310000);
	a[3]=new sanpham("/LKRapMay/Phukien/USB/USB 3.0 OTG lightning 32GB Sandisk Ixpand Mini.png","USB03","USB OTG Lightning 32GB",400000);
	a[4]=new sanpham("/LKRapMay/Phukien/USB/Usb 3.0 OTG Type-C 32G Sandisk.png","USB04","USB OTG Type",650000);
	a[5]=new sanpham("/LKRapMay/Phukien/USB/USB Sandisk SDCZ50 8GB 2.0.jpg","USB05","USB Sandisk 8GB",610000);
	a[6]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ Micro SD 128GB Sandisk C10.jpg","TNHO00","Thẻ nhớ Micro SD 128GB Sandisk",100000);
	a[7]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 8GB Kingston Class 4.png","TNHO01","Thẻ nhớ MicroSD 8GB Kingston",150000);
	a[8]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 16GB Kingston.jpg","TNHO02","Thẻ nhớ MicroSD 16GB Kingston",310000);
	a[9]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 16GB Remax Class 10.png","TNHO03","Thẻ nhớ MicroSD 16GB Remax",260000);
	a[10]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 16GB Sandisk C4.jpg","TNHO04","Thẻ nhớ MicroSD 16GB Sandisk",23000);
	a[11]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 32GB.png","TNHO05","Thẻ nhớ MicroSD 32GB",200000);
	a[12]=new sanpham("/LKRapMay/Phukien/Thenho/Thẻ nhớ MicroSD 64GB Kingston C10.jpg","TNHO06","Thẻ nhớ MicroSD 64GB Kingston",280000);
	a[13]=new sanpham("/LKRapMay/Phukien/Thietbimang/Bộ khuếch đại Wifi Asus RT-N800HP.png","TBM00","Bộ khuếch đại Asus",300000);
	a[14]=new sanpham("/LKRapMay/Phukien/Thietbimang/Bộ phát sóng không dây APTEK 196GU.jpg","TBM01","Bộ phát sóng không dây APTEK",650000);
	a[15]=new sanpham("/LKRapMay/Phukien/Thietbimang/Bộ phát sóng wifi Linksys EA6350.jpg","TBM02","Bộ phát sóng wifi Linksys",310000);
	a[16]=new sanpham("/LKRapMay/Phukien/Thietbimang/Draytek Vigor3900 Super Load.jpg","TBM03","Draytek Vigor3900 Super Load",400000);
	a[17]=new sanpham("/LKRapMay/Phukien/Thietbimang/Router Wifi ASUS ROG Rapture GT-AC5300 (Gaming Router) .png","TBM04","Router Wifi ASUS ROG Rapture",650000);
	a[18]=new sanpham("/LKRapMay/Phukien/Thietbimang/Router Wifi ASUS RT-AC86U (Gaming Router) AC2900 MU-MIMO hỗ trợ AiMesh, bảo vệ mạng AiProtection.jpg","TBM05","Router Wifi ASUS RT-AC86U",610000);
	a[19]=new sanpham("/LKRapMay/Phukien/Thietbimang/TP Link TL-WN725N.jpg","TBM06","TP Link TL-WN725N",610000);
	a[20]=new sanpham("/LKRapMay/Phukien/Thietbimang/TP-Link Archer C20 - AC750.jpg","TBM07","TP-Link Archer C20 - AC750",610000);
	a[21]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng bẫm sẵn Cat5e 2m Foxdigi Japan FD30.jpg","CAP00","Cáp mạng bẫm sẵn Cat5e 2m",300000);
	a[22]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng bẫm sẵn Cat5e 10m Foxdigi Japan FD150.jpg","CAP01","Cáp mạng bẫm sẵn Cat5e 10m",650000);
	a[23]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng bấm sẵn UTP Golden Japan 3 mét.jpg","CAP02","Cáp mạng bấm sẵn UTP Golden Japan 3 mét",310000);
	a[24]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng Cat6 UTP Orico 2m PUG-C6-20.jpg","CAP03","Cáp mạng Cat6 UTP Orico 2m",400000);
	a[25]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng Cat6e Tenda thùng cuộn 300m.jpg","CAP04","Cáp mạng Cat6e Tenda thùng cuộn 300m",650000);
	a[26]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng đúc sẵn Cat6 100m Ugreen UG-11228.jpg","CAP05","Cáp mạng đúc sẵn Cat6 100m",610000);
	a[27]=new sanpham("/LKRapMay/Phukien/Capcacloai/Cáp mạng đúc sẵn Cat6 dài 20m Ugreen UG-11221.jpg","CAP06","Cáp mạng đúc sẵn Cat6 dài 20m",60000);
	a[28]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Iwalk 12000mAh.png","SAC00","Sạc dự phòng Iwalk 12000mAh",300000);
	a[29]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng không dây Unik 10000mAh wireless.jpg","SAC01","Sạc dự phòng không dây Unik 10000mAh wireless",650000);
	a[30]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Proda 10000mAh wireless.png","SAC02","Sạc dự phòng Proda 10000mAh wireless",310000);
	a[31]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Prolink 15000mAh.jpg","SAC03","Sạc dự phòng Prolink 15000mAh",400000);
	a[32]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Unik 5000mAh.jpg","SAC04","Sạc dự phòng Unik 5000mAh",650000);
	a[33]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Unik 10000mAh (Quick Charger 3.0).png","SAC05","Sạc dự phòng Unik 10000mAh (Quick Charger 3.0)",100000);
	a[34]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Unik 10000mAh.png","SAC06","Sạc dự phòng Unik 10000mAh",310000);
	a[35]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc Dự Phòng Xiaomi 5.000 mAh.png","SAC07","Sạc Dự Phòng Xiaomi 5.000 mAh",610000);
	a[36]=new sanpham("/LKRapMay/Phukien/Sacduphong/Sạc dự phòng Yoobao 10200mAh.jpg","SAC08","Sạc dự phòng Yoobao 10200mAh",610000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = PK();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}
window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=12;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = PK();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});
