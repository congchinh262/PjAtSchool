//Format tiền//////////////////////////////
function formatPricetoPrint(a){
	a=a.toLocaleString()
	a=a.split(',').join('.');
	return a;
}
function formatPricetoMath(a){
	a=a.split('.').join('');
	return a;
}
//tạo database ảo://////////////////////////
function sanpham(pic,id,name,price)
{
	this.pic=pic;
	this.id=id;
	this.name=name;
	this.price=price;
}
function Main(){
	var a = new Array();
	a[0]=new sanpham("/LKRapMay/Mainboard/Code.jpg","MAIN00","Code",60000);
	a[1]=new sanpham("/LKRapMay/Mainboard/Extreme.jpg","MAIN01","Extreme",650000);
	a[2]=new sanpham("/LKRapMay/Mainboard/F_Gaming.jpg","MAIN02","F_Gaming",310000);
	a[3]=new sanpham("/LKRapMay/Mainboard/Formula.jpg","MAIN03","Formula",60000);
	a[4]=new sanpham("/LKRapMay/Mainboard/Mortar.jpg","MAIN04","Mortar",650000);
	a[5]=new sanpham("/LKRapMay/Mainboard/Pro4_F.jpg","MAIN05","Pro4_F",310000);
	a[6]=new sanpham("/LKRapMay/Mainboard/Z390_designare.jpg","MAIN06","Z390_designare",60000);
	a[7]=new sanpham("/LKRapMay/Mainboard/Z390_elite.jpg","MAIN07","Z390_elite",650000);
	a[8]=new sanpham("/LKRapMay/Mainboard/Z390_extreme.jpg","MAIN08","Z390_extreme",310000);
	a[9]=new sanpham("/LKRapMay/RAM/corsair_4gb.jpg","RAM00","Ram Corsair_4gb",100000);
	a[10]=new sanpham("/LKRapMay/RAM/corsair_8gb.jpg","RAM01","Ram Corsair_8gb",150000);
	a[11]=new sanpham("/LKRapMay/RAM/gskill_aegis_4gb.jpg","RAM02","Ram Gskill_aegis_4gb",310000);
	a[12]=new sanpham("/LKRapMay/RAM/gskill_aegis_8gb.jpg","RAM03","Ram Gskill_aegis_8gb",260000);
	a[13]=new sanpham("/LKRapMay/RAM/gskill_ripjaws_16gb.jpg","RAM04","Ram Gskill_ripjaws_16gb",23000);
	a[14]=new sanpham("/LKRapMay/RAM/gskill_trident_32gb.jpg","RAM05","Ram Gskill_trident_32gb",200000);
	a[15]=new sanpham("/LKRapMay/RAM/kingston_16gb.jpg","RAM06","Ram Kingston_16gb",280000);
	a[16]=new sanpham("/LKRapMay/Nguon/infinitygene_350w.jpg","BN00","Infinitygene_350w",60000);
	a[17]=new sanpham("/LKRapMay/Nguon/infinityrampage_500w.jpg","BN01","Infinityrampage_500we",650000);
	a[18]=new sanpham("/LKRapMay/Nguon/infinityrampage_750w.jpg","BN02","Infinityrampage_750w",310000);
	a[19]=new sanpham("/LKRapMay/Vga/gtx1030.jpg","VGA00","GTX 1030",60000);
	a[20]=new sanpham("/LKRapMay/Vga/gtx1050.jpg","VGA01","GTX 1050",650000);
	a[21]=new sanpham("/LKRapMay/Vga/gtx1050_ti.jpg","VGA02","GTX 1050 Ti",310000);
	a[22]=new sanpham("/LKRapMay/Vga/gtx1060.jpg","VGA03","Gtx1060",60000);
	a[23]=new sanpham("/LKRapMay/Vga/gtx1060_ti.jpg","VGA04","Gtx1060_ti",650000);
	a[24]=new sanpham("/LKRapMay/Vga/gtx1070.jpg","VGA05","Gtx1070",310000);
	a[25]=new sanpham("/LKRapMay/Vga/gtx1070_ti.jpg","VGA06","Gtx1070_ti",60000);
	a[26]=new sanpham("/LKRapMay/Vga/gtx1080_ti.jpg","VGA07","Gtx1080_ti",650000);
	a[27]=new sanpham("/LKRapMay/Vga/rtx2060.jpg","VGA08","Rtx2060",310000);
	a[28]=new sanpham("/LKRapMay/Vga/rtx2070.jpg","VGA09","Rtx2070",60000);
	a[29]=new sanpham("/LKRapMay/Vga/rtx2080.jpg","VGA10","Rtx2080",650000);
	a[30]=new sanpham("/LKRapMay/Vga/rtx2080ti.jpg","VGA11","Rtx2080ti",310000);
	return a;
}
//Hiện thông tin sản phẩm////////////////////////
function showDetail(code){
	document.getElementById('myModal').style.display = "block";
	var a = Main();
	for ( var i = 0 ; i<a.length ; i++){
		if(a[i].id == code ){
			document.getElementById("ten").innerHTML=a[i].name;
			document.getElementById("hinh").src="./image"+a[i].pic;
			document.getElementById("gia").innerHTML=formatPricetoPrint(a[i].price);
		}
	}
}

window.onclick = function(event) {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
function closeDetail(){
	document.getElementById('myModal').style.display = "none";
}
//Pagination///////////////////
function phantrang(page)
{
	var limit=12;
	var dem=0;
	var s1="";
	var start,num_page,current_page,record;
	start = (page-1)*limit; 
	var a = Main();
	record=a.length;
	if(record>limit)
	{
		num_page=Math.ceil(record/limit);
	}else{
		num_page=1;
	}
	s1+="<div class='row'>";
	for(var i=start; i<a.length ; i++)
	{
		s1+="<div class='col-lg-3 col-md-4 d-flex align-items-md-stretch'>"+
				"<div class='card'>"+
					"<div class='prdt-img'>"+
						"<img class='card-img-top card-img-size' src='./image"+a[i].pic+"' alt='Card image cap'/>"+
						"<div class='prdt-bg-opacity'>"+
							"<div class='prdt-command'>"+
								"<a onclick='showDetail("+'"'+a[i].id+'"'+")' class='btn btn-primary align-self-end btn-block text-white' style='margin-top: auto'>Xem chi tiết</a>"+
							"</div>"+
						"</div>"+
					"</div>"+
					"<div class='card-body d-flex flex-column'>"+
						"<h5 class='card-title'>"+a[i].name+"</h5>"+
						"<p class='card-text'>"+formatPricetoPrint(parseInt(a[i].price))+" VNĐ</p>"+
					"</div>"+
				"</div>"+
			"</div>";
		dem++;
		if(dem==limit) break;
	}
	s1+="</div>";
	s1+="<div style='clear:both'></div>";
	s1+="<ul class='pagination d-flex justify-content-center '>";
	if(num_page>1)
	{
		current_page=page;
		if(current_page!=1)
		{
			s1+="<li  class='page-item' onclick='phantrang(1);'><a class='page-link' href='#product'>Đầu</a></li>";
			s1+="<li  class='page-item' onclick='phantrang("+(page-1)+");'><a class='page-link' href='#product'>Trước</a></li>";
		}
		for(var i=1;i<=num_page;i++)
		{
			if(i!=current_page)
			{
				s1+="<li class='page-item' onclick='phantrang("+i+");'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
			else{
				s1+="<li class='page-item active'><a class='page-link' href='#product'>"+i+"</a></li>";
			}
		}
		if(current_page!=num_page)
		{
			s1+="<li class='page-item' onclick='phantrang("+(parseInt(page)+1)+");'><a class='page-link' href='#product'>Sau</a></li>";
			s1+="<li class='page-item' onclick='phantrang("+num_page+");'><a class='page-link' href='#product'>Cuối</a></li>";
		}
	}
	s1+="</ul>";
	$('#content').html(s1);
	// if ( a == "")
	// { s1="<div style='float:left; overflow:hidden; text-align:center; font-size:15px; font-weight:700; width:80%'>"+
	// 		"<h1>KHÔNG CÓ SẢN PHẨM PHÙ HỢP</h1>"+
	// 		"</div>"
	// 	$('#content').html(s1);
	// }
}

$(document).ready(function(){
	phantrang(1);
});